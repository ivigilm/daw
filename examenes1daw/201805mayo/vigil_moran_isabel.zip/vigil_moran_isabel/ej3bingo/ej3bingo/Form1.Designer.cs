﻿namespace ej3bingo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTjugar = new System.Windows.Forms.Button();
            this.LVnumeros = new System.Windows.Forms.ListView();
            this.LABbombo = new System.Windows.Forms.Label();
            this.BT01carton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BT03carton = new System.Windows.Forms.Button();
            this.BT04carton = new System.Windows.Forms.Button();
            this.BT05carton = new System.Windows.Forms.Button();
            this.BT06carton = new System.Windows.Forms.Button();
            this.BT07carton = new System.Windows.Forms.Button();
            this.BT08carton = new System.Windows.Forms.Button();
            this.BT09carton = new System.Windows.Forms.Button();
            this.BT10carton = new System.Windows.Forms.Button();
            this.BT11carton = new System.Windows.Forms.Button();
            this.BT12carton = new System.Windows.Forms.Button();
            this.BT13carton = new System.Windows.Forms.Button();
            this.BT14carton = new System.Windows.Forms.Button();
            this.BT15carton = new System.Windows.Forms.Button();
            this.BTbola = new System.Windows.Forms.Button();
            this.GBcarton = new System.Windows.Forms.GroupBox();
            this.LABnumextraido = new System.Windows.Forms.Label();
            this.LABlinea = new System.Windows.Forms.Label();
            this.GBcarton.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTjugar
            // 
            this.BTjugar.Location = new System.Drawing.Point(53, 476);
            this.BTjugar.Name = "BTjugar";
            this.BTjugar.Size = new System.Drawing.Size(112, 58);
            this.BTjugar.TabIndex = 0;
            this.BTjugar.Text = "Empezar partida";
            this.BTjugar.UseVisualStyleBackColor = true;
            this.BTjugar.Click += new System.EventHandler(this.BTjugar_Click);
            // 
            // LVnumeros
            // 
            this.LVnumeros.Location = new System.Drawing.Point(12, 29);
            this.LVnumeros.Name = "LVnumeros";
            this.LVnumeros.Size = new System.Drawing.Size(656, 343);
            this.LVnumeros.TabIndex = 1;
            this.LVnumeros.UseCompatibleStateImageBehavior = false;
            this.LVnumeros.View = System.Windows.Forms.View.List;
            // 
            // LABbombo
            // 
            this.LABbombo.AutoSize = true;
            this.LABbombo.Location = new System.Drawing.Point(12, 9);
            this.LABbombo.Name = "LABbombo";
            this.LABbombo.Size = new System.Drawing.Size(52, 17);
            this.LABbombo.TabIndex = 2;
            this.LABbombo.Text = "Bombo";
            // 
            // BT01carton
            // 
            this.BT01carton.Location = new System.Drawing.Point(15, 30);
            this.BT01carton.Name = "BT01carton";
            this.BT01carton.Size = new System.Drawing.Size(75, 59);
            this.BT01carton.TabIndex = 3;
            this.BT01carton.UseVisualStyleBackColor = true;
            this.BT01carton.Click += new System.EventHandler(this.BT01carton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(96, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 59);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // BT03carton
            // 
            this.BT03carton.Location = new System.Drawing.Point(175, 30);
            this.BT03carton.Name = "BT03carton";
            this.BT03carton.Size = new System.Drawing.Size(75, 59);
            this.BT03carton.TabIndex = 5;
            this.BT03carton.UseVisualStyleBackColor = true;
            this.BT03carton.Click += new System.EventHandler(this.BT03carton_Click);
            // 
            // BT04carton
            // 
            this.BT04carton.Location = new System.Drawing.Point(256, 30);
            this.BT04carton.Name = "BT04carton";
            this.BT04carton.Size = new System.Drawing.Size(75, 59);
            this.BT04carton.TabIndex = 6;
            this.BT04carton.UseVisualStyleBackColor = true;
            this.BT04carton.Click += new System.EventHandler(this.BT04carton_Click);
            // 
            // BT05carton
            // 
            this.BT05carton.Location = new System.Drawing.Point(337, 30);
            this.BT05carton.Name = "BT05carton";
            this.BT05carton.Size = new System.Drawing.Size(75, 59);
            this.BT05carton.TabIndex = 7;
            this.BT05carton.UseVisualStyleBackColor = true;
            this.BT05carton.Click += new System.EventHandler(this.BT05carton_Click);
            // 
            // BT06carton
            // 
            this.BT06carton.Location = new System.Drawing.Point(15, 95);
            this.BT06carton.Name = "BT06carton";
            this.BT06carton.Size = new System.Drawing.Size(75, 58);
            this.BT06carton.TabIndex = 8;
            this.BT06carton.UseVisualStyleBackColor = true;
            this.BT06carton.Click += new System.EventHandler(this.BT06carton_Click);
            // 
            // BT07carton
            // 
            this.BT07carton.Location = new System.Drawing.Point(96, 95);
            this.BT07carton.Name = "BT07carton";
            this.BT07carton.Size = new System.Drawing.Size(73, 58);
            this.BT07carton.TabIndex = 9;
            this.BT07carton.UseVisualStyleBackColor = true;
            this.BT07carton.Click += new System.EventHandler(this.BT07carton_Click);
            // 
            // BT08carton
            // 
            this.BT08carton.Location = new System.Drawing.Point(175, 95);
            this.BT08carton.Name = "BT08carton";
            this.BT08carton.Size = new System.Drawing.Size(75, 58);
            this.BT08carton.TabIndex = 10;
            this.BT08carton.UseVisualStyleBackColor = true;
            this.BT08carton.Click += new System.EventHandler(this.BT08carton_Click);
            // 
            // BT09carton
            // 
            this.BT09carton.Location = new System.Drawing.Point(256, 95);
            this.BT09carton.Name = "BT09carton";
            this.BT09carton.Size = new System.Drawing.Size(75, 58);
            this.BT09carton.TabIndex = 11;
            this.BT09carton.UseVisualStyleBackColor = true;
            this.BT09carton.Click += new System.EventHandler(this.BT09carton_Click);
            // 
            // BT10carton
            // 
            this.BT10carton.Location = new System.Drawing.Point(337, 95);
            this.BT10carton.Name = "BT10carton";
            this.BT10carton.Size = new System.Drawing.Size(75, 58);
            this.BT10carton.TabIndex = 12;
            this.BT10carton.UseVisualStyleBackColor = true;
            this.BT10carton.Click += new System.EventHandler(this.BT10carton_Click);
            // 
            // BT11carton
            // 
            this.BT11carton.Location = new System.Drawing.Point(15, 159);
            this.BT11carton.Name = "BT11carton";
            this.BT11carton.Size = new System.Drawing.Size(75, 58);
            this.BT11carton.TabIndex = 13;
            this.BT11carton.UseVisualStyleBackColor = true;
            this.BT11carton.Click += new System.EventHandler(this.BT11carton_Click);
            // 
            // BT12carton
            // 
            this.BT12carton.Location = new System.Drawing.Point(96, 159);
            this.BT12carton.Name = "BT12carton";
            this.BT12carton.Size = new System.Drawing.Size(75, 58);
            this.BT12carton.TabIndex = 14;
            this.BT12carton.UseVisualStyleBackColor = true;
            this.BT12carton.Click += new System.EventHandler(this.BT12carton_Click);
            // 
            // BT13carton
            // 
            this.BT13carton.Location = new System.Drawing.Point(177, 159);
            this.BT13carton.Name = "BT13carton";
            this.BT13carton.Size = new System.Drawing.Size(75, 58);
            this.BT13carton.TabIndex = 15;
            this.BT13carton.UseVisualStyleBackColor = true;
            this.BT13carton.Click += new System.EventHandler(this.BT13carton_Click);
            // 
            // BT14carton
            // 
            this.BT14carton.Location = new System.Drawing.Point(258, 159);
            this.BT14carton.Name = "BT14carton";
            this.BT14carton.Size = new System.Drawing.Size(75, 58);
            this.BT14carton.TabIndex = 16;
            this.BT14carton.UseVisualStyleBackColor = true;
            this.BT14carton.Click += new System.EventHandler(this.BT14carton_Click);
            // 
            // BT15carton
            // 
            this.BT15carton.Location = new System.Drawing.Point(337, 159);
            this.BT15carton.Name = "BT15carton";
            this.BT15carton.Size = new System.Drawing.Size(75, 58);
            this.BT15carton.TabIndex = 17;
            this.BT15carton.UseVisualStyleBackColor = true;
            this.BT15carton.Click += new System.EventHandler(this.BT15carton_Click);
            // 
            // BTbola
            // 
            this.BTbola.Location = new System.Drawing.Point(66, 540);
            this.BTbola.Name = "BTbola";
            this.BTbola.Size = new System.Drawing.Size(99, 58);
            this.BTbola.TabIndex = 18;
            this.BTbola.Text = "Sacar bola";
            this.BTbola.UseVisualStyleBackColor = true;
            this.BTbola.Visible = false;
            this.BTbola.Click += new System.EventHandler(this.BTbola_Click);
            // 
            // GBcarton
            // 
            this.GBcarton.Controls.Add(this.BT01carton);
            this.GBcarton.Controls.Add(this.button2);
            this.GBcarton.Controls.Add(this.BT15carton);
            this.GBcarton.Controls.Add(this.BT03carton);
            this.GBcarton.Controls.Add(this.BT14carton);
            this.GBcarton.Controls.Add(this.BT04carton);
            this.GBcarton.Controls.Add(this.BT13carton);
            this.GBcarton.Controls.Add(this.BT05carton);
            this.GBcarton.Controls.Add(this.BT12carton);
            this.GBcarton.Controls.Add(this.BT06carton);
            this.GBcarton.Controls.Add(this.BT11carton);
            this.GBcarton.Controls.Add(this.BT07carton);
            this.GBcarton.Controls.Add(this.BT10carton);
            this.GBcarton.Controls.Add(this.BT08carton);
            this.GBcarton.Controls.Add(this.BT09carton);
            this.GBcarton.Location = new System.Drawing.Point(244, 405);
            this.GBcarton.Name = "GBcarton";
            this.GBcarton.Size = new System.Drawing.Size(424, 230);
            this.GBcarton.TabIndex = 19;
            this.GBcarton.TabStop = false;
            this.GBcarton.Text = "Cartón";
            // 
            // LABnumextraido
            // 
            this.LABnumextraido.AutoSize = true;
            this.LABnumextraido.Location = new System.Drawing.Point(77, 467);
            this.LABnumextraido.Name = "LABnumextraido";
            this.LABnumextraido.Size = new System.Drawing.Size(0, 17);
            this.LABnumextraido.TabIndex = 20;
            // 
            // LABlinea
            // 
            this.LABlinea.AutoSize = true;
            this.LABlinea.Location = new System.Drawing.Point(88, 405);
            this.LABlinea.Name = "LABlinea";
            this.LABlinea.Size = new System.Drawing.Size(0, 17);
            this.LABlinea.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 650);
            this.Controls.Add(this.LABlinea);
            this.Controls.Add(this.LABnumextraido);
            this.Controls.Add(this.GBcarton);
            this.Controls.Add(this.BTbola);
            this.Controls.Add(this.LABbombo);
            this.Controls.Add(this.LVnumeros);
            this.Controls.Add(this.BTjugar);
            this.Name = "Form1";
            this.Text = "¡Bingo!";
            this.GBcarton.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTjugar;
        private System.Windows.Forms.ListView LVnumeros;
        private System.Windows.Forms.Label LABbombo;
        private System.Windows.Forms.Button BT01carton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button BT03carton;
        private System.Windows.Forms.Button BT04carton;
        private System.Windows.Forms.Button BT05carton;
        private System.Windows.Forms.Button BT06carton;
        private System.Windows.Forms.Button BT07carton;
        private System.Windows.Forms.Button BT08carton;
        private System.Windows.Forms.Button BT09carton;
        private System.Windows.Forms.Button BT10carton;
        private System.Windows.Forms.Button BT11carton;
        private System.Windows.Forms.Button BT12carton;
        private System.Windows.Forms.Button BT13carton;
        private System.Windows.Forms.Button BT14carton;
        private System.Windows.Forms.Button BT15carton;
        private System.Windows.Forms.Button BTbola;
        private System.Windows.Forms.GroupBox GBcarton;
        private System.Windows.Forms.Label LABnumextraido;
        private System.Windows.Forms.Label LABlinea;
    }
}

